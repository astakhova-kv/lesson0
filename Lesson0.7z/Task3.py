#3rd program
a = 1234
b = 5678
print((a % 1000 // 10) + (b % 1000 // 10))