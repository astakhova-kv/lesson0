#4th program
ab = 13.42
cd = 42.13
a = int(ab)
b = int(ab * 100 % 100)
c = int(cd)
d = int(cd * 100 % 100)
print(a == d or b == c)